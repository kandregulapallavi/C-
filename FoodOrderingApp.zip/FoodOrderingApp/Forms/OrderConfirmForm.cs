using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace FoodOrderingApp
{
    public class OrderConfirmForm : Form
    {
        private Order _order;
        private int _orderId;
        private Timer _progressTimer;
        private Label lblStatus;
        private ProgressBar progressBar;
        private int _step = 0;

        private readonly string[] _statusSteps =
        {
            "✅  Order Confirmed!",
            "👨‍🍳  Being Prepared...",
            "🛵  Out for Delivery...",
            "🎉  Delivered! Enjoy your meal!"
        };

        public OrderConfirmForm(Order order, int orderId)
        {
            _order = order;
            _orderId = orderId;
            InitializeComponent();
            StartStatusAnimation();
        }

        private void InitializeComponent()
        {
            this.Text = "Order Confirmed!";
            this.Size = new Size(480, 560);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.White;
            this.Font = new Font("Segoe UI", 10f);

            // Success Banner
            var pnlBanner = new Panel
            {
                Dock = DockStyle.Top,
                Height = 100,
                BackColor = Color.FromArgb(34, 197, 94)
            };

            var lblCheck = new Label
            {
                Text = "🎉",
                Font = new Font("Segoe UI Emoji", 30f),
                AutoSize = true,
                ForeColor = Color.White,
                Location = new Point(20, 20)
            };
            var lblSuccess = new Label
            {
                Text = "Order Placed Successfully!",
                Font = new Font("Segoe UI", 16f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(80, 15)
            };
            var lblOrderNum = new Label
            {
                Text = $"Order #{_orderId}",
                Font = new Font("Segoe UI", 11f),
                ForeColor = Color.FromArgb(200, 255, 220),
                AutoSize = true,
                Location = new Point(80, 50)
            };
            pnlBanner.Controls.AddRange(new Control[] { lblCheck, lblSuccess, lblOrderNum });
            this.Controls.Add(pnlBanner);

            int y = 115;

            // Status
            AddInfoRow("👤 Customer", _order.CustomerName, ref y);
            AddInfoRow("📱 Phone", _order.Phone, ref y);
            AddInfoRow("📍 Address", _order.Address, ref y);
            AddInfoRow("💳 Payment", _order.PaymentMethod, ref y);
            AddInfoRow("🕐 Order Time", _order.OrderTime.ToString("hh:mm tt, dd MMM yyyy"), ref y);

            // Divider
            var div = new Panel { Location = new Point(20, y), Size = new Size(430, 1), BackColor = Color.FromArgb(230, 230, 230) };
            this.Controls.Add(div);
            y += 10;

            // Items summary
            var lblItemsHead = new Label
            {
                Text = "Items Ordered:",
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(100, 100, 100),
                AutoSize = true,
                Location = new Point(20, y)
            };
            this.Controls.Add(lblItemsHead);
            y += 22;

            foreach (var item in _order.Items)
            {
                var lbl = new Label
                {
                    Text = $"  {item.Food.Emoji} {item.Food.Name}  x{item.Quantity}   ₹{item.TotalPrice:F0}",
                    Font = new Font("Segoe UI", 9f),
                    ForeColor = Color.FromArgb(60, 60, 60),
                    AutoSize = true,
                    Location = new Point(20, y)
                };
                this.Controls.Add(lbl);
                y += 20;
            }

            y += 5;
            var lblGrand = new Label
            {
                Text = $"Grand Total: ₹{_order.GrandTotal:F2}",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(255, 94, 58),
                AutoSize = true,
                Location = new Point(20, y)
            };
            this.Controls.Add(lblGrand);
            y += 35;

            // Live status
            lblStatus = new Label
            {
                Text = _statusSteps[0],
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(34, 197, 94),
                AutoSize = false,
                Size = new Size(430, 28),
                Location = new Point(20, y),
                TextAlign = ContentAlignment.MiddleCenter
            };
            this.Controls.Add(lblStatus);
            y += 35;

            progressBar = new ProgressBar
            {
                Location = new Point(20, y),
                Size = new Size(430, 18),
                Minimum = 0,
                Maximum = 100,
                Value = 0,
                Style = ProgressBarStyle.Continuous
            };
            this.Controls.Add(progressBar);
            y += 35;

            var btnClose = new Button
            {
                Text = "Back to Menu",
                Size = new Size(200, 44),
                Location = new Point(130, y),
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(255, 94, 58),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.Click += (s, e) => this.Close();
            this.Controls.Add(btnClose);
        }

        private void AddInfoRow(string label, string value, ref int y)
        {
            var l = new Label { Text = label + ":", Font = new Font("Segoe UI", 9f, FontStyle.Bold), ForeColor = Color.FromArgb(120, 120, 120), AutoSize = true, Location = new Point(20, y) };
            var v = new Label { Text = value, Font = new Font("Segoe UI", 9f), ForeColor = Color.FromArgb(40, 40, 40), AutoSize = true, Location = new Point(120, y) };
            this.Controls.AddRange(new Control[] { l, v });
            y += 22;
        }

        private void StartStatusAnimation()
        {
            _progressTimer = new Timer { Interval = 1500 };
            _progressTimer.Tick += (s, e) =>
            {
                _step++;
                if (_step < _statusSteps.Length)
                {
                    lblStatus.Text = _statusSteps[_step];
                    progressBar.Value = Math.Min((_step * 100) / (_statusSteps.Length - 1), 100);
                    if (_step == _statusSteps.Length - 1)
                    {
                        lblStatus.ForeColor = Color.FromArgb(255, 94, 58);
                        _progressTimer.Stop();
                    }
                }
            };
            _progressTimer.Start();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _progressTimer?.Stop();
            _progressTimer?.Dispose();
            base.OnFormClosed(e);
        }
    }
}
