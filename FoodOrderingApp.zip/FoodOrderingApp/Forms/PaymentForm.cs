using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace FoodOrderingApp
{
    public class PaymentForm : Form
    {
        private List<CartItem> _cart;
        private string _name, _phone, _address;
        private RadioButton rbCash, rbCard, rbUPI;
        private TextBox txtUPI, txtCard, txtCVV;
        private Label lblTotal;
        private Button btnPay;

        public PaymentForm(List<CartItem> cart, string name, string phone, string address)
        {
            _cart = cart;
            _name = name;
            _phone = phone;
            _address = address;
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "FoodieExpress - Payment";
            this.Size = new Size(480, 560);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.White;
            this.Font = new Font("Segoe UI", 10f);

            // Header
            var pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(255, 94, 58)
            };
            var lblHead = new Label
            {
                Text = "💳  Secure Payment",
                Font = new Font("Segoe UI", 15f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 15)
            };
            pnlHeader.Controls.Add(lblHead);
            this.Controls.Add(pnlHeader);

            int y = 75;

            // Order Summary
            AddSectionLabel("📋 Order Summary", ref y);
            decimal subTotal = _cart.Sum(c => c.TotalPrice);
            decimal tax = Math.Round(subTotal * 0.05m, 2);
            decimal delivery = 40m;
            decimal grand = subTotal + tax + delivery;

            var summaryPanel = new Panel
            {
                Location = new Point(20, y),
                Size = new Size(430, 100),
                BackColor = Color.FromArgb(255, 248, 245),
                BorderStyle = BorderStyle.FixedSingle
            };

            AddSummaryRow(summaryPanel, $"Items ({_cart.Sum(c => c.Quantity)})", $"₹{subTotal:F2}", 5);
            AddSummaryRow(summaryPanel, "GST (5%)", $"₹{tax:F2}", 28);
            AddSummaryRow(summaryPanel, "Delivery Fee", $"₹{delivery:F2}", 51);
            var pnlDivider = new Panel { Location = new Point(5, 74), Size = new Size(418, 1), BackColor = Color.FromArgb(230, 130, 100) };
            var lblGrand = new Label { Text = "Grand Total", Font = new Font("Segoe UI", 11f, FontStyle.Bold), Location = new Point(5, 76), AutoSize = true };
            var lblGrandAmt = new Label { Text = $"₹{grand:F2}", Font = new Font("Segoe UI", 11f, FontStyle.Bold), ForeColor = Color.FromArgb(255, 94, 58), AutoSize = true };
            lblGrandAmt.Location = new Point(420 - lblGrandAmt.PreferredWidth - 5, 76);
            summaryPanel.Controls.AddRange(new Control[] { pnlDivider, lblGrand, lblGrandAmt });
            this.Controls.Add(summaryPanel);
            y += 115;

            // Payment Method
            AddSectionLabel("💳 Payment Method", ref y);

            rbCash = CreateRadio("💵  Cash on Delivery", new Point(25, y)); y += 35;
            rbUPI = CreateRadio("📱  UPI (GPay / PhonePe)", new Point(25, y)); y += 35;
            rbCard = CreateRadio("💳  Debit / Credit Card", new Point(25, y)); y += 45;
            rbCash.Checked = true;

            this.Controls.AddRange(new Control[] { rbCash, rbUPI, rbCard });

            // UPI field
            txtUPI = new TextBox
            {
                Location = new Point(25, y),
                Size = new Size(400, 30),
                Font = new Font("Segoe UI", 10f),
                PlaceholderText = "Enter UPI ID (e.g. name@upi)",
                BorderStyle = BorderStyle.FixedSingle,
                Visible = false
            };
            this.Controls.Add(txtUPI);

            // Card fields
            txtCard = new TextBox
            {
                Location = new Point(25, y),
                Size = new Size(260, 30),
                Font = new Font("Segoe UI", 10f),
                PlaceholderText = "Card Number (16 digits)",
                BorderStyle = BorderStyle.FixedSingle,
                Visible = false
            };
            txtCVV = new TextBox
            {
                Location = new Point(295, y),
                Size = new Size(130, 30),
                Font = new Font("Segoe UI", 10f),
                PlaceholderText = "CVV",
                PasswordChar = '●',
                BorderStyle = BorderStyle.FixedSingle,
                Visible = false
            };
            this.Controls.AddRange(new Control[] { txtCard, txtCVV });

            rbUPI.CheckedChanged += (s, e) => { txtUPI.Visible = rbUPI.Checked; txtCard.Visible = false; txtCVV.Visible = false; };
            rbCard.CheckedChanged += (s, e) => { txtCard.Visible = rbCard.Checked; txtCVV.Visible = rbCard.Checked; txtUPI.Visible = false; };
            rbCash.CheckedChanged += (s, e) => { txtUPI.Visible = false; txtCard.Visible = false; txtCVV.Visible = false; };

            // Pay Button
            btnPay = new Button
            {
                Text = $"PAY  ₹{grand:F2}  →",
                Size = new Size(430, 50),
                Location = new Point(20, 470),
                Font = new Font("Segoe UI", 13f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(34, 197, 94),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnPay.FlatAppearance.BorderSize = 0;
            btnPay.Click += BtnPay_Click;
            this.Controls.Add(btnPay);

            lblTotal = new Label { Text = $"₹{grand:F2}", Visible = false };
            lblTotal.Tag = grand;
        }

        private void AddSectionLabel(string text, ref int y)
        {
            var lbl = new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(60, 60, 60),
                AutoSize = true,
                Location = new Point(20, y)
            };
            this.Controls.Add(lbl);
            y += 28;
        }

        private void AddSummaryRow(Panel panel, string label, string value, int y)
        {
            var l = new Label { Text = label, AutoSize = true, Location = new Point(5, y), Font = new Font("Segoe UI", 9f) };
            var v = new Label { Text = value, AutoSize = true, Font = new Font("Segoe UI", 9f), ForeColor = Color.FromArgb(80, 80, 80) };
            v.Location = new Point(420 - v.PreferredWidth - 5, y);
            panel.Controls.AddRange(new Control[] { l, v });
        }

        private RadioButton CreateRadio(string text, Point loc)
        {
            return new RadioButton
            {
                Text = text,
                Location = loc,
                AutoSize = true,
                Font = new Font("Segoe UI", 10f),
                ForeColor = Color.FromArgb(40, 40, 40),
                Cursor = Cursors.Hand
            };
        }

        private void BtnPay_Click(object sender, EventArgs e)
        {
            string payMethod = rbCash.Checked ? "Cash on Delivery" : rbUPI.Checked ? "UPI" : "Card";

            if (rbUPI.Checked && string.IsNullOrWhiteSpace(txtUPI.Text))
            { MessageBox.Show("Please enter your UPI ID.", "Required", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (rbCard.Checked && (txtCard.Text.Length != 16 || string.IsNullOrWhiteSpace(txtCVV.Text)))
            { MessageBox.Show("Please enter valid card number (16 digits) and CVV.", "Required", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            var order = new Order
            {
                CustomerName = _name,
                Phone = _phone,
                Address = _address,
                PaymentMethod = payMethod,
                Items = new List<CartItem>(_cart)
            };
            int orderId = DataService.PlaceOrder(order);

            // Show confirmation
            var confirm = new OrderConfirmForm(order, orderId);
            this.DialogResult = DialogResult.OK;
            this.Close();
            confirm.ShowDialog();
        }
    }
}
