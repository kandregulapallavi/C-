using System;
using System.Drawing;
using System.Windows.Forms;

namespace FoodOrderingApp
{
    public class LoginForm : Form
    {
        private TextBox txtName;
        private TextBox txtPhone;
        private TextBox txtAddress;
        private Button btnLogin;
        private Label lblTitle;
        private Label lblSubtitle;
        private Panel pnlCard;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "FoodieExpress - Login";
            this.Size = new Size(480, 560);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(255, 94, 58);
            this.Font = new Font("Segoe UI", 10f);

            // Card Panel
            pnlCard = new Panel
            {
                Size = new Size(400, 460),
                Location = new Point(40, 50),
                BackColor = Color.White
            };
            pnlCard.Paint += (s, e) =>
            {
                var g = e.Graphics;
                using (var pen = new Pen(Color.FromArgb(230, 230, 230), 1))
                    g.DrawRectangle(pen, 0, 0, pnlCard.Width - 1, pnlCard.Height - 1);
            };

            // Title
            lblTitle = new Label
            {
                Text = "🍔 FoodieExpress",
                Font = new Font("Segoe UI", 22f, FontStyle.Bold),
                ForeColor = Color.FromArgb(255, 94, 58),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(400, 50),
                Location = new Point(0, 30)
            };

            lblSubtitle = new Label
            {
                Text = "Order delicious food to your doorstep",
                Font = new Font("Segoe UI", 10f),
                ForeColor = Color.FromArgb(120, 120, 120),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Size = new Size(400, 25),
                Location = new Point(0, 80)
            };

            // Name Field
            AddLabel(pnlCard, "👤  Your Name", new Point(40, 130));
            txtName = CreateTextBox(new Point(40, 155), "Enter your full name");
            pnlCard.Controls.Add(txtName);

            // Phone Field
            AddLabel(pnlCard, "📱  Phone Number", new Point(40, 215));
            txtPhone = CreateTextBox(new Point(40, 240), "Enter 10-digit mobile number");
            pnlCard.Controls.Add(txtPhone);

            // Address Field
            AddLabel(pnlCard, "📍  Delivery Address", new Point(40, 300));
            txtAddress = new TextBox
            {
                Size = new Size(320, 70),
                Location = new Point(40, 325),
                Font = new Font("Segoe UI", 11f),
                Multiline = true,
                BorderStyle = BorderStyle.FixedSingle,
                ForeColor = Color.FromArgb(100, 100, 100),
                Text = "Enter your delivery address"
            };
            SetupPlaceholder(txtAddress, "Enter your delivery address");
            pnlCard.Controls.Add(txtAddress);

            // Login Button
            btnLogin = new Button
            {
                Text = "START ORDERING  →",
                Size = new Size(320, 48),
                Location = new Point(40, 400),
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(255, 94, 58),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += BtnLogin_Click;
            btnLogin.MouseEnter += (s, e) => btnLogin.BackColor = Color.FromArgb(220, 70, 30);
            btnLogin.MouseLeave += (s, e) => btnLogin.BackColor = Color.FromArgb(255, 94, 58);
            pnlCard.Controls.Add(btnLogin);

            pnlCard.Controls.Add(lblTitle);
            pnlCard.Controls.Add(lblSubtitle);
            this.Controls.Add(pnlCard);
        }

        private void AddLabel(Panel panel, string text, Point location)
        {
            var lbl = new Label
            {
                Text = text,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(80, 80, 80),
                AutoSize = true,
                Location = location
            };
            panel.Controls.Add(lbl);
        }

        private TextBox CreateTextBox(Point location, string placeholder)
        {
            var txt = new TextBox
            {
                Size = new Size(320, 35),
                Location = location,
                Font = new Font("Segoe UI", 11f),
                BorderStyle = BorderStyle.FixedSingle,
                ForeColor = Color.FromArgb(100, 100, 100),
                Text = placeholder
            };
            SetupPlaceholder(txt, placeholder);
            return txt;
        }

        private void SetupPlaceholder(TextBox txt, string placeholder)
        {
            txt.ForeColor = Color.FromArgb(180, 180, 180);
            txt.GotFocus += (s, e) =>
            {
                if (txt.Text == placeholder)
                {
                    txt.Text = "";
                    txt.ForeColor = Color.FromArgb(30, 30, 30);
                }
            };
            txt.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txt.Text))
                {
                    txt.Text = placeholder;
                    txt.ForeColor = Color.FromArgb(180, 180, 180);
                }
            };
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string phone = txtPhone.Text.Trim();
            string address = txtAddress.Text.Trim();

            string namePlaceholder = "Enter your full name";
            string phonePlaceholder = "Enter 10-digit mobile number";
            string addressPlaceholder = "Enter your delivery address";

            if (name == namePlaceholder || string.IsNullOrEmpty(name))
            {
                ShowError("Please enter your name.");
                txtName.Focus();
                return;
            }
            if (phone == phonePlaceholder || phone.Length != 10 || !long.TryParse(phone, out _))
            {
                ShowError("Please enter a valid 10-digit phone number.");
                txtPhone.Focus();
                return;
            }
            if (address == addressPlaceholder || string.IsNullOrEmpty(address))
            {
                ShowError("Please enter your delivery address.");
                txtAddress.Focus();
                return;
            }

            var mainForm = new MainForm(name, phone, address);
            mainForm.Show();
            this.Hide();
            mainForm.FormClosed += (s2, e2) => this.Close();
        }

        private void ShowError(string message)
        {
            MessageBox.Show(message, "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
