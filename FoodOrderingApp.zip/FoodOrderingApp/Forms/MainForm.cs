using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace FoodOrderingApp
{
    public class MainForm : Form
    {
        // Data
        private string _customerName, _customerPhone, _customerAddress;
        private List<FoodItem> _allItems;
        private List<CartItem> _cart = new List<CartItem>();
        private string _selectedCategory = "All";

        // UI Controls
        private Panel pnlHeader, pnlSidebar, pnlContent, pnlCart;
        private FlowLayoutPanel flpCategories, flpItems;
        private Panel pnlCartItems;
        private Label lblCartTotal, lblCartCount, lblGreeting;
        private TextBox txtSearch;
        private Button btnCheckout;
        private Label lblEmptyCart;

        public MainForm(string name, string phone, string address)
        {
            _customerName = name;
            _customerPhone = phone;
            _customerAddress = address;
            _allItems = DataService.GetAllFoodItems();
            InitializeComponent();
            LoadCategories();
            LoadItems("All", "");
        }

        private void InitializeComponent()
        {
            this.Text = "FoodieExpress - Menu";
            this.Size = new Size(1200, 750);
            this.MinimumSize = new Size(1000, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(245, 245, 245);
            this.Font = new Font("Segoe UI", 9f);

            BuildHeader();
            BuildSidebar();
            BuildContent();
            BuildCartPanel();
        }

        // ─── HEADER ───────────────────────────────────────────────
        private void BuildHeader()
        {
            pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 65,
                BackColor = Color.FromArgb(255, 94, 58)
            };

            var lblLogo = new Label
            {
                Text = "🍔 FoodieExpress",
                Font = new Font("Segoe UI", 18f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 15)
            };

            lblGreeting = new Label
            {
                Text = $"Hello, {_customerName}! 👋",
                Font = new Font("Segoe UI", 10f),
                ForeColor = Color.FromArgb(255, 220, 200),
                AutoSize = true,
                Location = new Point(240, 22)
            };

            txtSearch = new TextBox
            {
                Size = new Size(260, 32),
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle,
                ForeColor = Color.FromArgb(180, 180, 180),
                Text = "🔍  Search food...",
                BackColor = Color.White
            };
            txtSearch.GotFocus += (s, e) => { if (txtSearch.Text.StartsWith("🔍")) { txtSearch.Text = ""; txtSearch.ForeColor = Color.Black; } };
            txtSearch.LostFocus += (s, e) => { if (string.IsNullOrWhiteSpace(txtSearch.Text)) { txtSearch.Text = "🔍  Search food..."; txtSearch.ForeColor = Color.FromArgb(180, 180, 180); } };
            txtSearch.TextChanged += (s, e) => LoadItems(_selectedCategory, txtSearch.Text.StartsWith("🔍") ? "" : txtSearch.Text);

            var btnOrders = new Button
            {
                Text = "📋 My Orders",
                Size = new Size(110, 32),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(200, 60, 20),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnOrders.FlatAppearance.BorderSize = 0;
            btnOrders.Click += (s, e) => new OrderHistoryForm().ShowDialog();

            pnlHeader.Controls.AddRange(new Control[] { lblLogo, lblGreeting, txtSearch, btnOrders });
            this.Controls.Add(pnlHeader);

            pnlHeader.Resize += (s, e) =>
            {
                txtSearch.Location = new Point(pnlHeader.Width - 420, 17);
                btnOrders.Location = new Point(pnlHeader.Width - 150, 17);
            };
            pnlHeader.PerformLayout();
        }

        // ─── SIDEBAR (Categories) ─────────────────────────────────
        private void BuildSidebar()
        {
            pnlSidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 160,
                BackColor = Color.White,
                Padding = new Padding(10, 10, 10, 10)
            };

            var lblCat = new Label
            {
                Text = "CATEGORIES",
                Font = new Font("Segoe UI", 8f, FontStyle.Bold),
                ForeColor = Color.FromArgb(150, 150, 150),
                AutoSize = false,
                Width = 140,
                Location = new Point(10, 15)
            };

            flpCategories = new FlowLayoutPanel
            {
                Location = new Point(5, 40),
                Size = new Size(150, 550),
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true
            };

            pnlSidebar.Controls.Add(lblCat);
            pnlSidebar.Controls.Add(flpCategories);
            this.Controls.Add(pnlSidebar);
        }

        private void LoadCategories()
        {
            flpCategories.Controls.Clear();
            foreach (var cat in DataService.GetCategories())
            {
                string catName = cat;
                var btn = new Button
                {
                    Text = GetCategoryEmoji(catName) + "  " + catName,
                    Size = new Size(140, 42),
                    FlatStyle = FlatStyle.Flat,
                    TextAlign = ContentAlignment.MiddleLeft,
                    Font = new Font("Segoe UI", 10f),
                    Cursor = Cursors.Hand,
                    Margin = new Padding(0, 2, 0, 2)
                };
                btn.FlatAppearance.BorderSize = 0;
                SetCategoryButtonStyle(btn, catName == _selectedCategory);
                btn.Click += (s, e) =>
                {
                    _selectedCategory = catName;
                    foreach (Button b in flpCategories.Controls)
                        SetCategoryButtonStyle(b, b.Text.EndsWith(catName));
                    LoadItems(catName, txtSearch.Text.StartsWith("🔍") ? "" : txtSearch.Text);
                };
                flpCategories.Controls.Add(btn);
            }
        }

        private void SetCategoryButtonStyle(Button btn, bool active)
        {
            btn.BackColor = active ? Color.FromArgb(255, 94, 58) : Color.White;
            btn.ForeColor = active ? Color.White : Color.FromArgb(60, 60, 60);
        }

        private string GetCategoryEmoji(string cat)
        {
            switch (cat)
            {
                case "All": return "🍽";
                case "Burgers": return "🍔";
                case "Pizza": return "🍕";
                case "Biryani": return "🍛";
                case "Chinese": return "🍜";
                case "Desserts": return "🍰";
                case "Drinks": return "🥤";
                default: return "🍽";
            }
        }

        // ─── CONTENT (Food Items) ─────────────────────────────────
        private void BuildContent()
        {
            pnlContent = new Panel
            {
                BackColor = Color.FromArgb(245, 245, 245),
                Padding = new Padding(15)
            };
            pnlContent.SuspendLayout();

            flpItems = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                AutoScroll = true,
                Padding = new Padding(5)
            };

            pnlContent.Controls.Add(flpItems);
            pnlContent.ResumeLayout();
            this.Controls.Add(pnlContent);
        }

        private void LoadItems(string category, string search)
        {
            flpItems.SuspendLayout();
            flpItems.Controls.Clear();

            var items = _allItems
                .Where(f => (category == "All" || f.Category == category))
                .Where(f => string.IsNullOrEmpty(search) || f.Name.ToLower().Contains(search.ToLower()))
                .ToList();

            if (items.Count == 0)
            {
                var lblNone = new Label
                {
                    Text = "😔  No items found",
                    Font = new Font("Segoe UI", 13f),
                    ForeColor = Color.FromArgb(180, 180, 180),
                    AutoSize = true,
                    Margin = new Padding(40)
                };
                flpItems.Controls.Add(lblNone);
            }
            else
            {
                foreach (var item in items)
                    flpItems.Controls.Add(CreateFoodCard(item));
            }

            flpItems.ResumeLayout();
        }

        private Panel CreateFoodCard(FoodItem item)
        {
            var card = new Panel
            {
                Size = new Size(210, 220),
                BackColor = Color.White,
                Margin = new Padding(8),
                Cursor = Cursors.Default
            };

            card.Paint += (s, e) =>
            {
                var g = e.Graphics;
                using (var pen = new Pen(Color.FromArgb(235, 235, 235)))
                    g.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
            };

            var lblEmoji = new Label
            {
                Text = item.Emoji,
                Font = new Font("Segoe UI Emoji", 36f),
                AutoSize = false,
                Size = new Size(210, 80),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(0, 10),
                BackColor = Color.FromArgb(255, 248, 245)
            };

            var lblName = new Label
            {
                Text = item.Name,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 30, 30),
                AutoSize = false,
                Size = new Size(190, 36),
                Location = new Point(10, 95),
                TextAlign = ContentAlignment.TopLeft
            };

            var lblDesc = new Label
            {
                Text = item.Description,
                Font = new Font("Segoe UI", 8f),
                ForeColor = Color.FromArgb(130, 130, 130),
                AutoSize = false,
                Size = new Size(190, 32),
                Location = new Point(10, 128),
                TextAlign = ContentAlignment.TopLeft
            };

            var lblPrice = new Label
            {
                Text = $"₹{item.Price}",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.FromArgb(255, 94, 58),
                AutoSize = true,
                Location = new Point(10, 165)
            };

            var btnAdd = new Button
            {
                Text = "+ Add",
                Size = new Size(75, 30),
                Location = new Point(125, 160),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(255, 94, 58),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.Click += (s, e) => AddToCart(item);
            btnAdd.MouseEnter += (s, e) => btnAdd.BackColor = Color.FromArgb(220, 70, 30);
            btnAdd.MouseLeave += (s, e) => btnAdd.BackColor = Color.FromArgb(255, 94, 58);

            card.Controls.AddRange(new Control[] { lblEmoji, lblName, lblDesc, lblPrice, btnAdd });
            return card;
        }

        // ─── CART PANEL ────────────────────────────────────────────
        private void BuildCartPanel()
        {
            pnlCart = new Panel
            {
                Dock = DockStyle.Right,
                Width = 290,
                BackColor = Color.White
            };

            // Cart header
            var pnlCartHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 55,
                BackColor = Color.FromArgb(30, 30, 30)
            };

            lblCartCount = new Label
            {
                Text = "🛒  Cart (0)",
                Font = new Font("Segoe UI", 13f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(15, 15)
            };
            pnlCartHeader.Controls.Add(lblCartCount);

            // Empty cart label
            lblEmptyCart = new Label
            {
                Text = "Your cart is empty.\nAdd items to get started! 🍽",
                Font = new Font("Segoe UI", 10f),
                ForeColor = Color.FromArgb(180, 180, 180),
                AutoSize = false,
                Size = new Size(270, 60),
                Location = new Point(10, 20),
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Cart items scrollable panel
            pnlCartItems = new Panel
            {
                Location = new Point(0, 55),
                Size = new Size(290, 490),
                AutoScroll = true,
                BackColor = Color.White
            };
            pnlCartItems.Controls.Add(lblEmptyCart);

            // Cart footer
            var pnlCartFooter = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 145,
                BackColor = Color.FromArgb(250, 250, 250)
            };
            pnlCartFooter.Paint += (s, e) =>
                e.Graphics.DrawLine(new Pen(Color.FromArgb(230, 230, 230)), 0, 0, pnlCartFooter.Width, 0);

            lblCartTotal = new Label
            {
                Text = "Total: ₹0.00",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 30, 30),
                AutoSize = false,
                Size = new Size(270, 30),
                Location = new Point(10, 15),
                TextAlign = ContentAlignment.MiddleLeft
            };

            var lblDelivery = new Label
            {
                Text = "Delivery: ₹40  |  GST 5%",
                Font = new Font("Segoe UI", 8f),
                ForeColor = Color.FromArgb(140, 140, 140),
                AutoSize = false,
                Size = new Size(270, 20),
                Location = new Point(10, 45)
            };

            btnCheckout = new Button
            {
                Text = "PLACE ORDER  🎉",
                Size = new Size(260, 48),
                Location = new Point(15, 75),
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(34, 197, 94),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                Enabled = false
            };
            btnCheckout.FlatAppearance.BorderSize = 0;
            btnCheckout.Click += BtnCheckout_Click;
            btnCheckout.MouseEnter += (s, e) => { if (btnCheckout.Enabled) btnCheckout.BackColor = Color.FromArgb(22, 163, 74); };
            btnCheckout.MouseLeave += (s, e) => { if (btnCheckout.Enabled) btnCheckout.BackColor = Color.FromArgb(34, 197, 94); };

            pnlCartFooter.Controls.AddRange(new Control[] { lblCartTotal, lblDelivery, btnCheckout });

            pnlCart.Controls.Add(pnlCartHeader);
            pnlCart.Controls.Add(pnlCartItems);
            pnlCart.Controls.Add(pnlCartFooter);
            this.Controls.Add(pnlCart);

            // Position content between sidebar and cart
            pnlContent.Location = new Point(160, 65);
            RepositionContent();
            this.Resize += (s, e) => RepositionContent();
        }

        private void RepositionContent()
        {
            pnlContent.Size = new Size(this.ClientSize.Width - 160 - 290, this.ClientSize.Height - 65);
            pnlSidebar.Height = this.ClientSize.Height - 65;
            pnlSidebar.Top = 65;
            pnlCart.Height = this.ClientSize.Height - 65;
            pnlCart.Top = 65;
            pnlCartItems.Size = new Size(290, pnlCart.Height - 55 - 145);
        }

        // ─── CART LOGIC ────────────────────────────────────────────
        private void AddToCart(FoodItem item)
        {
            var existing = _cart.FirstOrDefault(c => c.Food.Id == item.Id);
            if (existing != null)
                existing.Quantity++;
            else
                _cart.Add(new CartItem(item));
            RefreshCart();
        }

        private void RefreshCart()
        {
            pnlCartItems.SuspendLayout();
            pnlCartItems.Controls.Clear();

            if (_cart.Count == 0)
            {
                lblEmptyCart.Location = new Point(10, 20);
                pnlCartItems.Controls.Add(lblEmptyCart);
                lblCartCount.Text = "🛒  Cart (0)";
                lblCartTotal.Text = "Total: ₹0.00";
                btnCheckout.Enabled = false;
                btnCheckout.BackColor = Color.FromArgb(150, 150, 150);
                pnlCartItems.ResumeLayout();
                return;
            }

            int totalQty = _cart.Sum(c => c.Quantity);
            lblCartCount.Text = $"🛒  Cart ({totalQty})";
            btnCheckout.Enabled = true;
            btnCheckout.BackColor = Color.FromArgb(34, 197, 94);

            int y = 5;
            foreach (var cartItem in _cart.ToList())
            {
                var row = CreateCartRow(cartItem);
                row.Location = new Point(0, y);
                pnlCartItems.Controls.Add(row);
                y += row.Height + 2;
            }

            decimal subTotal = _cart.Sum(c => c.TotalPrice);
            decimal tax = Math.Round(subTotal * 0.05m, 2);
            decimal grand = subTotal + 40 + tax;
            lblCartTotal.Text = $"Grand Total: ₹{grand:F2}";
            pnlCartItems.ResumeLayout();
        }

        private Panel CreateCartRow(CartItem cartItem)
        {
            var row = new Panel
            {
                Size = new Size(285, 68),
                BackColor = Color.White
            };
            row.Paint += (s, e) =>
                e.Graphics.DrawLine(new Pen(Color.FromArgb(240, 240, 240)), 0, row.Height - 1, row.Width, row.Height - 1);

            var lblName = new Label
            {
                Text = cartItem.Food.Emoji + " " + cartItem.Food.Name,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 30, 30),
                AutoSize = false,
                Size = new Size(185, 20),
                Location = new Point(8, 8)
            };

            var lblPrice = new Label
            {
                Text = $"₹{cartItem.TotalPrice:F0}",
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(255, 94, 58),
                AutoSize = true,
                Location = new Point(240, 8)
            };

            var btnMinus = new Button
            {
                Text = "−",
                Size = new Size(26, 26),
                Location = new Point(8, 35),
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(255, 94, 58),
                BackColor = Color.FromArgb(255, 245, 242),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnMinus.FlatAppearance.BorderSize = 0;
            btnMinus.Click += (s, e) =>
            {
                cartItem.Quantity--;
                if (cartItem.Quantity <= 0) _cart.Remove(cartItem);
                RefreshCart();
            };

            var lblQty = new Label
            {
                Text = cartItem.Quantity.ToString(),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 30, 30),
                AutoSize = false,
                Size = new Size(30, 26),
                Location = new Point(38, 35),
                TextAlign = ContentAlignment.MiddleCenter
            };

            var btnPlus = new Button
            {
                Text = "+",
                Size = new Size(26, 26),
                Location = new Point(72, 35),
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(255, 94, 58),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnPlus.FlatAppearance.BorderSize = 0;
            btnPlus.Click += (s, e) => { cartItem.Quantity++; RefreshCart(); };

            var btnRemove = new Button
            {
                Text = "✕",
                Size = new Size(24, 24),
                Location = new Point(255, 38),
                Font = new Font("Segoe UI", 8f),
                ForeColor = Color.FromArgb(180, 180, 180),
                BackColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnRemove.FlatAppearance.BorderSize = 0;
            btnRemove.Click += (s, e) => { _cart.Remove(cartItem); RefreshCart(); };

            row.Controls.AddRange(new Control[] { lblName, lblPrice, btnMinus, lblQty, btnPlus, btnRemove });
            return row;
        }

        // ─── CHECKOUT ──────────────────────────────────────────────
        private void BtnCheckout_Click(object sender, EventArgs e)
        {
            var payForm = new PaymentForm(_cart, _customerName, _customerPhone, _customerAddress);
            if (payForm.ShowDialog() == DialogResult.OK)
            {
                _cart.Clear();
                RefreshCart();
            }
        }
    }
}
