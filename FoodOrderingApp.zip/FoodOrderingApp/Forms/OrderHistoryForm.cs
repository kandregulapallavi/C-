using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace FoodOrderingApp
{
    public class OrderHistoryForm : Form
    {
        public OrderHistoryForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "My Orders";
            this.Size = new Size(600, 520);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;
            this.Font = new Font("Segoe UI", 10f);

            // Header
            var pnlHeader = new Panel { Dock = DockStyle.Top, Height = 55, BackColor = Color.FromArgb(255, 94, 58) };
            var lblTitle = new Label
            {
                Text = "📋  My Orders",
                Font = new Font("Segoe UI", 14f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(15, 14)
            };
            pnlHeader.Controls.Add(lblTitle);
            this.Controls.Add(pnlHeader);

            // Orders panel
            var pnlScroll = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(15) };
            this.Controls.Add(pnlScroll);

            var orders = DataService.GetOrders();
            if (orders.Count == 0)
            {
                var lblEmpty = new Label
                {
                    Text = "😔  No orders yet.\nStart ordering your favourite food!",
                    Font = new Font("Segoe UI", 12f),
                    ForeColor = Color.FromArgb(180, 180, 180),
                    AutoSize = false,
                    Size = new Size(560, 80),
                    Location = new Point(20, 80),
                    TextAlign = ContentAlignment.MiddleCenter
                };
                pnlScroll.Controls.Add(lblEmpty);
                return;
            }

            int y = 10;
            foreach (var order in orders.OrderByDescending(o => o.OrderTime))
            {
                var card = CreateOrderCard(order);
                card.Location = new Point(10, y);
                pnlScroll.Controls.Add(card);
                y += card.Height + 12;
            }
        }

        private Panel CreateOrderCard(Order order)
        {
            int cardHeight = 90 + order.Items.Count * 20;
            var card = new Panel
            {
                Size = new Size(545, cardHeight),
                BackColor = Color.FromArgb(252, 252, 252),
                BorderStyle = BorderStyle.FixedSingle
            };

            // Card header bar
            var pnlTop = new Panel { Location = new Point(0, 0), Size = new Size(545, 36), BackColor = Color.FromArgb(255, 248, 245) };
            var lblId = new Label
            {
                Text = $"Order #{order.OrderId}",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(255, 94, 58),
                AutoSize = true,
                Location = new Point(10, 8)
            };
            var lblDate = new Label
            {
                Text = order.OrderTime.ToString("dd MMM yyyy  hh:mm tt"),
                Font = new Font("Segoe UI", 9f),
                ForeColor = Color.FromArgb(140, 140, 140),
                AutoSize = true,
                Location = new Point(160, 10)
            };
            var lblStatus = new Label
            {
                Text = "✅ " + order.Status,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = Color.FromArgb(34, 197, 94),
                AutoSize = true,
                Location = new Point(430, 10)
            };
            pnlTop.Controls.AddRange(new Control[] { lblId, lblDate, lblStatus });
            card.Controls.Add(pnlTop);

            int y = 42;
            foreach (var item in order.Items)
            {
                var lbl = new Label
                {
                    Text = $"  {item.Food.Emoji}  {item.Food.Name}  ×{item.Quantity}   →   ₹{item.TotalPrice:F0}",
                    Font = new Font("Segoe UI", 9f),
                    ForeColor = Color.FromArgb(60, 60, 60),
                    AutoSize = true,
                    Location = new Point(10, y)
                };
                card.Controls.Add(lbl);
                y += 20;
            }

            var lblPay = new Label
            {
                Text = $"Payment: {order.PaymentMethod}",
                Font = new Font("Segoe UI", 8f),
                ForeColor = Color.FromArgb(150, 150, 150),
                AutoSize = true,
                Location = new Point(10, y + 5)
            };
            var lblTotal = new Label
            {
                Text = $"Total: ₹{order.GrandTotal:F2}",
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                ForeColor = Color.FromArgb(255, 94, 58),
                AutoSize = true,
                Location = new Point(400, y + 5)
            };
            card.Controls.AddRange(new Control[] { lblPay, lblTotal });

            return card;
        }
    }
}
