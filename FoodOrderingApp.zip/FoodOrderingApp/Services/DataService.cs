using System.Collections.Generic;

namespace FoodOrderingApp
{
    public static class DataService
    {
        private static List<Order> _orders = new List<Order>();
        private static int _orderCounter = 1001;

        public static List<FoodItem> GetAllFoodItems()
        {
            return new List<FoodItem>
            {
                // Burgers
                new FoodItem(1,  "Classic Beef Burger",   "Burgers",  149, "Juicy beef patty with lettuce, tomato & cheese",        "🍔"),
                new FoodItem(2,  "Chicken Zinger Burger", "Burgers",  139, "Crispy fried chicken with spicy mayo",                   "🍔"),
                new FoodItem(3,  "Double Smash Burger",   "Burgers",  189, "Double smashed patties with special sauce",              "🍔"),
                new FoodItem(4,  "Veggie Burger",         "Burgers",  119, "Grilled veggie patty with fresh veggies",               "🍔"),

                // Pizza
                new FoodItem(5,  "Margherita Pizza",      "Pizza",    199, "Classic tomato, mozzarella & fresh basil",              "🍕"),
                new FoodItem(6,  "Pepperoni Pizza",       "Pizza",    249, "Loaded with spicy pepperoni slices",                    "🍕"),
                new FoodItem(7,  "BBQ Chicken Pizza",     "Pizza",    259, "Smoky BBQ base with grilled chicken",                   "🍕"),
                new FoodItem(8,  "Paneer Tikka Pizza",    "Pizza",    229, "Indian spiced paneer with capsicum & onion",            "🍕"),

                // Biryani
                new FoodItem(9,  "Chicken Biryani",       "Biryani",  179, "Aromatic basmati rice with tender chicken",             "🍛"),
                new FoodItem(10, "Mutton Biryani",        "Biryani",  229, "Slow-cooked mutton in fragrant spices",                 "🍛"),
                new FoodItem(11, "Veg Dum Biryani",       "Biryani",  149, "Mixed vegetables layered with spiced rice",             "🍛"),
                new FoodItem(12, "Egg Biryani",           "Biryani",  159, "Fluffy eggs cooked with aromatic rice",                 "🍛"),

                // Chinese
                new FoodItem(13, "Veg Fried Rice",        "Chinese",  129, "Wok-tossed rice with fresh vegetables",                "🍜"),
                new FoodItem(14, "Chicken Noodles",       "Chinese",  149, "Stir-fried noodles with chicken strips",               "🍜"),
                new FoodItem(15, "Manchurian",            "Chinese",  129, "Crispy balls in tangy Manchurian sauce",               "🍜"),
                new FoodItem(16, "Spring Rolls",          "Chinese",   99, "Crispy rolls filled with vegetables",                  "🥟"),

                // Desserts
                new FoodItem(17, "Chocolate Lava Cake",   "Desserts",  89, "Warm cake with flowing chocolate center",              "🍰"),
                new FoodItem(18, "Gulab Jamun",           "Desserts",  59, "Soft milk-solid balls in sugar syrup",                 "🍮"),
                new FoodItem(19, "Ice Cream Sundae",      "Desserts",  79, "3 scoops with hot fudge and nuts",                    "🍨"),
                new FoodItem(20, "Rasgulla",              "Desserts",  59, "Spongy cottage cheese balls in syrup",                 "🍡"),

                // Drinks
                new FoodItem(21, "Mango Lassi",           "Drinks",    69, "Thick yogurt-based mango smoothie",                   "🥭"),
                new FoodItem(22, "Cold Coffee",           "Drinks",    79, "Chilled blended coffee with cream",                   "☕"),
                new FoodItem(23, "Fresh Lime Soda",       "Drinks",    49, "Tangy lime with sparkling soda",                      "🍋"),
                new FoodItem(24, "Masala Chai",           "Drinks",    39, "Spiced Indian tea with milk",                         "🫖"),
            };
        }

        public static List<string> GetCategories()
        {
            return new List<string> { "All", "Burgers", "Pizza", "Biryani", "Chinese", "Desserts", "Drinks" };
        }

        public static int PlaceOrder(Order order)
        {
            order.OrderId = _orderCounter++;
            _orders.Add(order);
            return order.OrderId;
        }

        public static List<Order> GetOrders()
        {
            return new List<Order>(_orders);
        }
    }
}
