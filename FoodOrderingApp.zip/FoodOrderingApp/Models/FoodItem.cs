namespace FoodOrderingApp
{
    public class FoodItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public string Emoji { get; set; }

        public FoodItem(int id, string name, string category, decimal price, string description, string emoji)
        {
            Id = id;
            Name = name;
            Category = category;
            Price = price;
            Description = description;
            Emoji = emoji;
        }
    }
}
