namespace FoodOrderingApp
{
    public class CartItem
    {
        public FoodItem Food { get; set; }
        public int Quantity { get; set; }

        public decimal TotalPrice => Food.Price * Quantity;

        public CartItem(FoodItem food, int quantity = 1)
        {
            Food = food;
            Quantity = quantity;
        }
    }
}
