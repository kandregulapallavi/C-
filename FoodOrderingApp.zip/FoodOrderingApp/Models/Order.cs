using System;
using System.Collections.Generic;
using System.Linq;

namespace FoodOrderingApp
{
    public class Order
    {
        public int OrderId { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public List<CartItem> Items { get; set; }
        public DateTime OrderTime { get; set; }
        public string Status { get; set; }
        public string PaymentMethod { get; set; }

        public decimal SubTotal => Items.Sum(i => i.TotalPrice);
        public decimal DeliveryFee => 40m;
        public decimal Tax => Math.Round(SubTotal * 0.05m, 2);
        public decimal GrandTotal => SubTotal + DeliveryFee + Tax;

        public Order()
        {
            Items = new List<CartItem>();
            OrderTime = DateTime.Now;
            Status = "Confirmed";
        }
    }
}
