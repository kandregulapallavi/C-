# 🍔 FoodieExpress - Online Food Ordering System (C# WinForms)

A fully functional Windows Forms desktop application built in C# .NET 6.

---

## 📁 Project Structure

```
FoodOrderingApp/
├── FoodOrderingApp.csproj       ← Project file (open this in Visual Studio)
├── Program.cs                   ← Application entry point
├── Models/
│   ├── FoodItem.cs              ← Food item data model
│   ├── CartItem.cs              ← Cart item with quantity
│   └── Order.cs                 ← Order model with totals
├── Services/
│   └── DataService.cs           ← In-memory data & 24 food items
└── Forms/
    ├── LoginForm.cs             ← Customer login screen
    ├── MainForm.cs              ← Menu browser + cart
    ├── PaymentForm.cs           ← Payment (Cash / UPI / Card)
    ├── OrderConfirmForm.cs      ← Animated order confirmation
    └── OrderHistoryForm.cs      ← View all past orders
```

---

## 🚀 How to Run

### Requirements
- **Visual Studio 2022** (Community / Professional / Enterprise)
- **.NET 6.0 SDK** (or .NET 8.0 — update TargetFramework in .csproj)
- **Windows OS** (WinForms is Windows-only)

### Steps
1. Open **Visual Studio 2022**
2. Click **"Open a project or solution"**
3. Navigate to the `FoodOrderingApp` folder and open **`FoodOrderingApp.csproj`**
4. Press **F5** or click ▶ **Run**

---

## ✨ Features

| Feature | Details |
|---|---|
| 🔐 Login Screen | Name, phone, address validation |
| 🍽 Menu Browser | 24 food items across 6 categories |
| 🔍 Search | Real-time search filter |
| 🗂 Categories | Burgers, Pizza, Biryani, Chinese, Desserts, Drinks |
| 🛒 Live Cart | Add/remove, quantity controls, live total |
| 💳 Payment | Cash / UPI / Card with validation |
| 🎉 Confirmation | Animated order status tracker |
| 📋 Order History | All orders with full details |

---

## 🎨 UI Design
- **Color Theme**: Orange accent `#FF5E3A` on clean white
- **Typography**: Segoe UI throughout
- **Cards**: Hover effects, rounded feel
- **Cart**: Sticky right-side panel
- **Animations**: Progress-bar delivery tracking

---

## 📝 Notes
- All data is **in-memory** (resets on app restart)
- To add a database, integrate **Entity Framework Core** with SQLite
- To extend: add admin panel, real payment gateway, etc.
